Thanks for downloading Vitamin E's Ableton DJ template!
This template will make it super easy to start mixing EDM in Ableton Live!

For tutorial videos on how to use the DJ template, go to my YouTube channel here:
http://www.youtube.com/user/opensourcebeats/videos

Check out my music and mixes at:
http://SoundCloud.com/VitaminE
http://MixCloud.com/VitaminEMusic

Happy mixing!